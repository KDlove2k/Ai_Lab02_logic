/*bò là động vật sống dưới nước*/
is_aquatic(cow).

/*cá heo là động vật sống dưới nước*/
is_aquatic(dolphin).

/*cá voi là động vật sống dưới nước*/
is_aquatic(whale).

/*cá mập là động vật sống dưới nước*/
is_aquatic(shark).

/*con voi là động vật sống dưới nước*/
is_aquatic(elephant).

/*bò là động vật nuôi*/
is_domestic(cow).

/*trâu là động vật nuôi*/
is_domestic(buffalo).

/*mèo là động vật nuôi*/
is_domestic(cat).

/*sư tử là động vật nuôi*/
is_domestic(lion).

/*rắn là động vật nuôi*/
is_domestic(snake).

