/*Ếch là động vật lưỡng cư?*/
is_land_water_animal(frog).

/*voi là động vật ăn thịt?*/
is_predator(elephant).

/*sư tử là động vật ăn thịt?*/
is_predator(lion).

/*hổ là động vật ăn thịt?*/
is_predator(tiger).

/*cá heo là động vật ăn thịt?*/
is_predator(dolphin).

/*cá mập là động vật ăn thịt?*/
is_predator(shark).

/*con bò là động vật có vú ăn thịt*/
is_a_mammal_predator(cow).

/*con sư tử là động vật có vú ăn thịt*/
is_a_mammal_predator(lion).

/*con cá heo là động vật có vú ăn thịt*/
is_a_mammal_predator(dolphin).

/*con cá mập là động vật có vú ăn thịt*/
is_a_mammal_predator(shark).