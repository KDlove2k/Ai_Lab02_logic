/*voi là động vật ăn cỏ?*/
is_herbivore(elephant).

/*bò là động vật ăn cỏ?*/
is_herbivore(cow).

/*sư tử là động vật ăn cỏ?*/
is_herbivore(lion).

/*cá heo là động vật ăn cỏ?*/
is_herbivore(dolphin).

/*cá mập là động vật ăn cỏ?*/
is_herbivore(shark).

/*Loài sâu là động vật không xương sống?*/
is_invertebrate(caterpillar).

/*ếch là động vật ăn cỏ?*/
is_herbivore(frog).

/*chó là động vật ăn cỏ?*/
is_herbivore(dog).

/*mèo là động vật ăn cỏ?*/
is_herbivore(cat).

/*cá mập là động vật có vú ăn cỏ?*/
is_a_mammal_herbivore(shark).

/*con bò là động vật có vú ăn cỏ?*/
is_a_mammal_herbivore(cow).

/*cá mập là động vật có vú ăn cỏ?*/
is_a_mammal_herbivore(elephant).