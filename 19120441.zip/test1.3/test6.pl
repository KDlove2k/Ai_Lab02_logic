/*mèo là động vật có xương sống*/
is_vertebrate(cat).

/*chó là động vật có xương sống*/
is_vertebrate(dog).

/*sâu là động vật có xương sống*/
is_vertebrate(caterpillar).

/*cá heo là động vật có xương sống*/
is_vertebrate(dolphin).

/*bò là động vật có xương sống*/
is_vertebrate(cow).

/*cá mập là động vật có xương sống*/
is_vertebrate(shark).

/*hổ là động vật có xương sống*/
is_vertebrate(tiger).

/*ếch là động vật có xương sống*/
is_vertebrate(frog).

/*con voi là động vật có xương sống*/
is_vertebrate(elephant).

/*chim ưng là động vật có xương sống*/
is_vertebrate(eagle).