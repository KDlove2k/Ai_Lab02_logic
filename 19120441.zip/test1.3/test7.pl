/*động vật không xương sống?*/
is_invertebrate(X).

/*con bò có 4 chân?*/
has_legs(cow,4).

/*con chó có 4 chân?*/
has_legs(dog,4).

/*con hổ có 5 chân?*/
has_legs(tiger,5).

/*con rắn có 10 chân?/
has_legs(snake,10).

/*con voi có 4 chân?/
has_legs(elephant,4).

/*con mèo là loài bò sát?*/
is_reptile(cat).

/*con nào thuộc loài bò sát?*/
is_reptile(X).

/*con rắn là loài bò sát?*/
is_reptile(snake).

/*cá sấu là loài bò sát?*/
is_reptile(crocodile).
