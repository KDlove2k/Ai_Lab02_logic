/* con bò thuộc loài côn trùng?*/
is_insect(cow).

/* con chó thuộc loài côn trùng?*/
is_insect(dog).

/* chim sẻ thuộc loài côn trùng?*/
is_insect(sparrow).

/*cá heo thuộc loài chim?*/
is_bird(dolphin).

/*cá sấu thuộc loài chim?*/
is_bird(crocodile).

/*cá mập thuộc loài chim?*/
is_bird(shark).

/*động vật sống trên cạn và dưới nước?*/
is_land_water_animal(X).

/*cá sấu là động vật sống trên cạn và dưới nước?*/
is_land_water_animal(crocodile).

/*cá voi là động vật sống trên cạn và dưới nước?*/
is_land_water_animal(whale).

/*rắn là động vật sống trên cạn và dưới nước?*/
is_land_water_animal(snake).

