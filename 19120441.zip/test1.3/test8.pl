/* cá mập là loài cá?*/
is_fish(shark).

/* cá heo là loài cá?*/
is_fish(dolphin).

/* cá whale là loài cá?*/
is_fish(whale).

/* cá sấu là loài cá?*/
is_fish(crocodile).

/* ếch là loài cá?*/
is_fish(frog).

/* con gì thuộc loài côn trùng?*/
is_insect(X).

/* con gì thuộc loài bò sát?*/
is_reptile(X).

/* vài động vật thuộc động vật có vú?*/
is_mammal(X).

/*chim ưng sống dưới nước?*/
is_water_animal(eagle).

/* con sư tử thuộc loài bò sát?*/
is_reptile(lion).
