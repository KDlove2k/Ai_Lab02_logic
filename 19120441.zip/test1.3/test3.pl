/*chim ưng là động vật có cánh*/
has_wings(eagle).

/*chim ưng là động vật có cánh*/
has_wings(sparrow).

/*chim ưng là động vật có cánh*/
has_wings(dolphin).

/*chim ưng là động vật có cánh*/
has_wings(shark).

/*sâu là động vật có cánh*/
has_wings(caterpillar).

/*sư tử có thể bay lượn?*/
is_flying_animal(lion).

/*chim ưng có thể bay lượn?*/
is_flying_animal(eagle).

/*chim sẻ có thể bay lượn?*/
is_flying_animal(sparrow).

/*chó có thể bay lượn?*/
is_flying_animal(dog).

/*con mèo có thể bay lượn?*/
is_flying_animal(cat).
