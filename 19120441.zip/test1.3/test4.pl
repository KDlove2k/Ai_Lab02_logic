/*sư tử là động vật sống trên cạn?*/
is_land_animal(lion).

/*con voi là động vật sống trên cạn?*/
is_land_animal(elephant).

/*cá heo là động vật sống trên cạn?*/
is_land_animal(dolphin).

/*cá mập là động vật sống trên cạn?*/
is_land_animal(shark).

/*sâu là động vật sống trên cạn?*/
is_land_animal(caterpillar).

/*chó là động vật sống trên cạn?*/
is_land_animal(dog).

/*con bò là động vật sống trên cạn?*/
is_land_animal(cow).

/*ếch là động vật sống trên cạn?*/
is_land_animal(frog).

/*cá voi là động vật sống trên cạn?*/
is_land_animal(whale).

/*chim sẻ là động vật sống trên cạn?*/
is_land_animal(sparrow).
