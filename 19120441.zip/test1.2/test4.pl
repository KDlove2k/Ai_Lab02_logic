/*Ai là chồng của Camilla?*/
husband(Husband, camilla).

/* Ai là con của Harry?*/
parent(harry,Child).

/* Ông ngoại của Prince Harry là Philip?*/
grandfather(philip, harry).

/* Anh chị em ruột của Andrew là ai?*/
sibling(andrew, Person2).

/* Ai là mẹ của Princess Anne?*/
mother(Parent, anne).

/*Lena là con trai của ai?*/
son(lena,Parent).