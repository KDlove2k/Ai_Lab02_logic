/*** Elizabeth là mẹ của Princess Eugenie?***/
parent(elizabeth, eugenie).

/*Nữ hoàng Anh Elizabeth_ii qua đời rồi phải không>*/
deceased(elizabeth_ii).

/* anh chị em của Prince Charles là Princess Anne?*/
sibling(charles, anne).

/*Ai là chồng của Camilla?*/
husband(Husband, camilla).

/* Ông nội của Prince William là Philip ?*/
grandfather(philip, william).

/* Ai là mẹ của Princess Eugenie?*/
mother(Parent, eugenie).