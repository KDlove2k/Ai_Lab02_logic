/* Diana là mẹ của Prince Harry?*/
mother(diana, harry).

/* anh chị em của Princess Anne là Charles?*/
sibling(anne, charles).

/*Charles là ông nội của August?*/
grandfather(andrew, august).

/*Philip đã qua đời rồi đúng không?*/
deceased(philip).

/* Bố mẹ của Mia là Peter?*/
parent(peter,mia).

/*Con gái của Hary là Archie Harrison?*/
daughter(archie_harrison,harry).