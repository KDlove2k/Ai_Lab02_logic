/*Ai là chồng của Queen Elizabeth?*/
husband(Husband, elizabeth_ii).

/* Ai là anh chị em của Prince Charles?*/
sibling(Prince_Charles, Princess_Anne).

/*** Prince Charles có con không?***/
parent(charles, _).

/* Elizabeth_ii là mẹ của Prince Charles?*/
mother(elizabeth_ii, charles).

/* Ai là anh chị em của Prince Harry? */
sibling(harry, Person2).

/*Lilibet Diana là con gái của ai?*/
daughter(lilibet_diana,Parent).