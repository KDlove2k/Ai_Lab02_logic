/*William qua đời rồi phải không?*/
deceased(william).

/***Elizabeth_ii là mẹ của Anne phải không?***/
parent(elizabeth_ii, anne).

/*chồng của Princess Diana là Chales?*/
husband(charles, diana).

/* anh chị em của Prince William là Harry?*/
sibling(william, harry).

/* Ai là mẹ của Prince William?*/
mother(Parent, william).

/* Philip có phải là ông nội của Princess Anne?*/
grandfather(philip, anne).

/* George là con trai của ai?*/
son(george,Parent).